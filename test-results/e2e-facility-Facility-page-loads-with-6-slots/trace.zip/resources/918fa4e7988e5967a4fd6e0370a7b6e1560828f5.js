import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");import { ref, onMounted, computed } from "/node_modules/.vite/deps/vue.js?v=6d926545";
import { facilityService, getStatusBadgeClass } from "/src/services/facilityService.js";


const _sfc_main = {
  __name: 'App',
  setup(__props, { expose: __expose }) {
  __expose();

const slots = ref([])
const loading = ref(true)
const processingId = ref(null)
const toast = ref('')

// ADDED: simulated role  (no real authentication).
const selectedRole = ref('club')
const selectedClub = ref('Eurhythmix')
const clubs = [
  'Ardiente',
  'Artdicted',
  'Ballare',
  'Broadcast & Entertainment',
  'Caderas Latinas',
  'Chamber Choir',
  'Chinese Orchestra',
  'Eurhythmix',
  'Funk Movement',
  'Guitarissimo',
  'INDANCITY',
  'Ivory Keys',
  'Literati',
  'Malay Language & Cultural Club',
  'SMUSAIC',
  'Samba Masala',
  'SoundFoundry',
  'Stageit',
  'Stereometa',
  'Symphonia',
  'VOIX',
  'ACF ExCo',
]
const isAdmin = computed(() => selectedRole.value === 'admin')
const profileMenuOpen = ref(false)
const toastType = ref('info')

// ADDED: venue category filter tabs (values match venue_type in the data).
const categories = [
  { label: 'All Venues', value: 'All' },
  { label: 'Dance Studios', value: 'Dance Studio' },
  { label: 'Acoustic Rooms', value: 'Acoustic Room' },
  { label: 'Sports Courts', value: 'Sports Court' },
  { label: 'Multi-Purpose', value: 'Multi-Purpose' },
]
const selectedCategory = ref('All')
const filteredSlots = computed(() =>
  selectedCategory.value === 'All'
    ? slots.value
    : slots.value.filter((slot) => slot.venue_type === selectedCategory.value)
)

function selectProfile(role) {
  selectedRole.value = role
  profileMenuOpen.value = false
  toast.value = ''
}
async function loadSlots() {
  const res = await facilityService.getSlots()
  slots.value = res.data || []
}

//handles different facility actions
async function handleAction(slot, action, message) {
  if (processingId.value !== null) return
  processingId.value = slot.id
  try {
    const result = await action()
    if (!result.success || !result.data) throw new Error('Unable to update facility')
    await loadSlots()
    toastType.value = 'success'
    toast.value = message
  } catch (error) {
    toastType.value = 'danger'
    toast.value = `Error: ${error.message}`
  } finally {
    processingId.value = null
  }
}

async function handleRelease(slot) {
  await handleAction(slot,
    () => facilityService.releaseSlot(slot.id, selectedClub.value),
    `${slot.venue_name} released to marketplace!`)
}

async function handleConfirm(slot) {
  await handleAction(slot,
    () => facilityService.confirmPeerTransfer(slot.id),
    `${slot.venue_name} transfer confirmed!`)
}

async function handleClaim(slot) {
  await handleAction(slot,
    () => facilityService.claimSlot(slot.id, selectedClub.value),
    `${slot.venue_name} claim submitted for admin approval!`)
}

async function handleUndo(slot) {
  await handleAction(slot,
    () => facilityService.undoRelease(slot.id, selectedClub.value),
    `${slot.venue_name} release undone!`)
}

async function handleReject(slot) {
  await handleAction(slot,
    () => facilityService.rejectPeerTransfer(slot.id),
    `${slot.venue_name} claim rejected; slot available for claim again!`)
}

onMounted(async () => {
  try {
    await loadSlots()
  } catch (error) {
    toastType.value = 'danger'
    toast.value = `Error loading facilities: ${error.message}`
  } finally {
    loading.value = false
  }
})

const __returned__ = { slots, loading, processingId, toast, selectedRole, selectedClub, clubs, isAdmin, profileMenuOpen, toastType, categories, selectedCategory, filteredSlots, selectProfile, loadSlots, handleAction, handleRelease, handleConfirm, handleClaim, handleUndo, handleReject, ref, onMounted, computed, get facilityService() { return facilityService }, get getStatusBadgeClass() { return getStatusBadgeClass } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, createCommentVNode as _createCommentVNode, createTextVNode as _createTextVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, renderList as _renderList, Fragment as _Fragment, vModelSelect as _vModelSelect, withDirectives as _withDirectives, normalizeClass as _normalizeClass } from "/node_modules/.vite/deps/vue.js?v=6d926545"

const _hoisted_1 = { class: "container py-4" }
const _hoisted_2 = { class: "d-flex justify-content-between align-items-center mb-4 gap-3" }
const _hoisted_3 = { class: "text-start" }
const _hoisted_4 = { class: "badge bg-danger mt-3 w-50" }
const _hoisted_5 = { class: "d-flex align-items-center gap-2" }
const _hoisted_6 = { class: "position-relative" }
const _hoisted_7 = ["aria-expanded"]
const _hoisted_8 = {
  key: 0,
  class: "card shadow position-absolute end-0 mt-2 p-2",
  style: {"min-width":"190px","z-index":"10"}
}
const _hoisted_9 = {
  key: 0,
  class: "mb-3"
}
const _hoisted_10 = ["value"]
const _hoisted_11 = {
  key: 1,
  class: "alert alert-light border mb-3"
}
const _hoisted_12 = { class: "nav nav-pills mb-3" }
const _hoisted_13 = ["onClick"]
const _hoisted_14 = {
  key: 3,
  class: "text-center py-5"
}
const _hoisted_15 = {
  key: 4,
  class: "text-center text-muted py-5"
}
const _hoisted_16 = {
  key: 5,
  class: "row"
}
const _hoisted_17 = { class: "card p-3 shadow-sm h-100" }
const _hoisted_18 = { class: "d-flex justify-content-between align-items-start" }
const _hoisted_19 = { class: "fw-bold mb-1" }
const _hoisted_20 = { class: "text-muted mb-2" }
const _hoisted_21 = { class: "mb-1" }
const _hoisted_22 = { class: "mb-0 text-muted small" }
const _hoisted_23 = {
  key: 0,
  class: "mb-0 text-muted small"
}
const _hoisted_24 = {
  key: 1,
  class: "mb-0 text-muted small"
}
const _hoisted_25 = { class: "badge bg-dark font-monospace ms-1" }
const _hoisted_26 = { class: "mt-auto d-flex flex-wrap gap-2 pt-3" }
const _hoisted_27 = ["disabled", "onClick"]
const _hoisted_28 = ["disabled", "onClick"]
const _hoisted_29 = ["disabled", "onClick"]
const _hoisted_30 = ["disabled", "onClick"]
const _hoisted_31 = ["disabled", "onClick"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("div", _hoisted_2, [
      _createElementVNode("div", _hoisted_3, [
        _cache[7] || (_cache[7] = _createElementVNode("h2", { class: "fw-bold mb-0" }, "Pulse - Master Facility Calendar", -1 /* CACHED */)),
        _createElementVNode("div", _hoisted_4, _toDisplayString($setup.isAdmin ? 'Facility Admin' : $setup.selectedClub + ' EXCO'), 1 /* TEXT */)
      ]),
      _createCommentVNode(" Reset button for demo page "),
      _createElementVNode("div", _hoisted_5, [
        _createElementVNode("button", {
          type: "button",
          class: "btn btn-outline-danger btn-sm",
          onClick: _cache[0] || (_cache[0] = $event => {$setup.facilityService.resetData().then(() => { $setup.loadSlots(); $setup.toast = ''; })})
        }, " Reset Demo "),
        _createCommentVNode(" Profile menu: switch between Club EXCO and Facility Admin "),
        _createElementVNode("div", _hoisted_6, [
          _createElementVNode("button", {
            type: "button",
            class: "btn btn-outline-secondary d-flex align-items-center gap-2",
            "aria-expanded": $setup.profileMenuOpen,
            onClick: _cache[1] || (_cache[1] = $event => ($setup.profileMenuOpen = !$setup.profileMenuOpen))
          }, [
            _cache[8] || (_cache[8] = _createElementVNode("span", { "aria-hidden": "true" }, "👤", -1 /* CACHED */)),
            _createTextVNode(" " + _toDisplayString($setup.isAdmin ? 'Facility Admin' : 'Club EXCO') + " ", 1 /* TEXT */),
            _cache[9] || (_cache[9] = _createElementVNode("span", { "aria-hidden": "true" }, "▾", -1 /* CACHED */))
          ], 8 /* PROPS */, _hoisted_7),
          ($setup.profileMenuOpen)
            ? (_openBlock(), _createElementBlock("div", _hoisted_8, [
                _createElementVNode("button", {
                  type: "button",
                  class: "btn btn-light text-start mb-1",
                  onClick: _cache[2] || (_cache[2] = $event => ($setup.selectProfile('club')))
                }, " Club EXCO "),
                _createElementVNode("button", {
                  type: "button",
                  class: "btn btn-light text-start",
                  onClick: _cache[3] || (_cache[3] = $event => ($setup.selectProfile('admin')))
                }, " Facility Admin ")
              ]))
            : _createCommentVNode("v-if", true)
        ])
      ])
    ]),
    _createCommentVNode(" Club switcher appears only for Club EXCO "),
    (!$setup.isAdmin)
      ? (_openBlock(), _createElementBlock("div", _hoisted_9, [
          _cache[10] || (_cache[10] = _createElementVNode("label", {
            for: "clubSwitcher",
            class: "form-label fw-bold"
          }, "Club Switcher", -1 /* CACHED */)),
          _withDirectives(_createElementVNode("select", {
            id: "clubSwitcher",
            "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.selectedClub) = $event)),
            class: "form-select",
            onChange: _cache[5] || (_cache[5] = $event => ($setup.toast = ''))
          }, [
            (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.clubs, (club) => {
              return _createElementVNode("option", {
                key: club,
                value: club
              }, _toDisplayString(club), 9 /* TEXT, PROPS */, _hoisted_10)
            }), 64 /* STABLE_FRAGMENT */))
          ], 544 /* NEED_HYDRATION, NEED_PATCH */), [
            [_vModelSelect, $setup.selectedClub]
          ])
        ]))
      : (_openBlock(), _createElementBlock("div", _hoisted_11, [...(_cache[11] || (_cache[11] = [
          _createElementVNode("strong", null, "Facility Admin ", -1 /* CACHED */)
        ]))])),
    _createCommentVNode(" Venue category filter tabs "),
    _createElementVNode("ul", _hoisted_12, [
      (_openBlock(), _createElementBlock(_Fragment, null, _renderList($setup.categories, (category) => {
        return _createElementVNode("li", {
          key: category.value,
          class: "nav-item"
        }, [
          _createElementVNode("button", {
            type: "button",
            class: _normalizeClass(["nav-link", { active: $setup.selectedCategory === category.value }]),
            onClick: $event => ($setup.selectedCategory = category.value)
          }, _toDisplayString(category.label), 11 /* TEXT, CLASS, PROPS */, _hoisted_13)
        ])
      }), 64 /* STABLE_FRAGMENT */))
    ]),
    _createCommentVNode(" Original alert banner: shown only for the user clicking an action "),
    ($setup.toast)
      ? (_openBlock(), _createElementBlock("div", {
          key: 2,
          class: _normalizeClass(["alert alert-dismissible fade show", `alert-${$setup.toastType}`]),
          role: "alert"
        }, [
          _createTextVNode(_toDisplayString($setup.toast) + " ", 1 /* TEXT */),
          _createElementVNode("button", {
            type: "button",
            class: "btn-close",
            onClick: _cache[6] || (_cache[6] = $event => ($setup.toast = ''))
          })
        ], 2 /* CLASS */))
      : _createCommentVNode("v-if", true),
    ($setup.loading)
      ? (_openBlock(), _createElementBlock("div", _hoisted_14, [...(_cache[12] || (_cache[12] = [
          _createElementVNode("div", {
            class: "spinner-border text-danger",
            role: "status"
          }, null, -1 /* CACHED */),
          _createElementVNode("p", { class: "text-muted mt-2" }, "Loading facility slots...", -1 /* CACHED */)
        ]))]))
      : (!$setup.filteredSlots.length)
        ? (_openBlock(), _createElementBlock("p", _hoisted_15, " No facility slots in this category. "))
        : (_openBlock(), _createElementBlock("div", _hoisted_16, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.filteredSlots, (slot) => {
              return (_openBlock(), _createElementBlock("div", {
                key: slot.id,
                class: "col-md-6 mb-3"
              }, [
                _createElementVNode("div", _hoisted_17, [
                  _createElementVNode("div", _hoisted_18, [
                    _createElementVNode("h5", _hoisted_19, _toDisplayString(slot.venue_name), 1 /* TEXT */),
                    _createElementVNode("span", {
                      class: _normalizeClass($setup.getStatusBadgeClass(slot.status))
                    }, _toDisplayString(slot.status), 3 /* TEXT, CLASS */)
                  ]),
                  _createElementVNode("small", _hoisted_20, _toDisplayString(slot.building_location), 1 /* TEXT */),
                  _createElementVNode("p", _hoisted_21, [
                    _cache[13] || (_cache[13] = _createElementVNode("strong", null, "Time:", -1 /* CACHED */)),
                    _createTextVNode(" " + _toDisplayString(slot.time_slot), 1 /* TEXT */)
                  ]),
                  _createElementVNode("p", _hoisted_22, [
                    _cache[14] || (_cache[14] = _createElementVNode("strong", null, "Owner:", -1 /* CACHED */)),
                    _createTextVNode(" " + _toDisplayString(slot.owner_club), 1 /* TEXT */)
                  ]),
                  (slot.claiming_club)
                    ? (_openBlock(), _createElementBlock("p", _hoisted_23, [
                        _cache[15] || (_cache[15] = _createElementVNode("strong", null, "Claiming Club:", -1 /* CACHED */)),
                        _createTextVNode(" " + _toDisplayString(slot.claiming_club), 1 /* TEXT */)
                      ]))
                    : _createCommentVNode("v-if", true),
                  (slot.audit_ticket_id)
                    ? (_openBlock(), _createElementBlock("p", _hoisted_24, [
                        _cache[16] || (_cache[16] = _createElementVNode("strong", null, "Audit Ticket:", -1 /* CACHED */)),
                        _createElementVNode("span", _hoisted_25, _toDisplayString(slot.audit_ticket_id), 1 /* TEXT */)
                      ]))
                    : _createCommentVNode("v-if", true),
                  _createCommentVNode(" Same action button section, with role-specific conditions "),
                  _createElementVNode("div", _hoisted_26, [
                    (!$setup.isAdmin && (slot.status === 'Booked' || slot.status === 'Officially Confirmed') && slot.owner_club === $setup.selectedClub)
                      ? (_openBlock(), _createElementBlock("button", {
                          key: 0,
                          class: "btn btn-outline-primary btn-sm",
                          disabled: $setup.processingId !== null,
                          onClick: $event => ($setup.handleRelease(slot))
                        }, " Release to Marketplace ", 8 /* PROPS */, _hoisted_27))
                      : _createCommentVNode("v-if", true),
                    (!$setup.isAdmin && slot.status === 'Proposed Peer Transfer' && slot.owner_club === $setup.selectedClub)
                      ? (_openBlock(), _createElementBlock("button", {
                          key: 1,
                          class: "btn btn-outline-secondary btn-sm",
                          disabled: $setup.processingId !== null,
                          onClick: $event => ($setup.handleUndo(slot))
                        }, " Undo Release ", 8 /* PROPS */, _hoisted_28))
                      : _createCommentVNode("v-if", true),
                    (!$setup.isAdmin && slot.status === 'Proposed Peer Transfer' && slot.owner_club !== $setup.selectedClub)
                      ? (_openBlock(), _createElementBlock("button", {
                          key: 2,
                          class: "btn btn-primary btn-sm",
                          disabled: $setup.processingId !== null,
                          onClick: $event => ($setup.handleClaim(slot))
                        }, " Claim Facility ", 8 /* PROPS */, _hoisted_29))
                      : _createCommentVNode("v-if", true),
                    ($setup.isAdmin && slot.status === 'Pending Admin Sign-off')
                      ? (_openBlock(), _createElementBlock("button", {
                          key: 3,
                          class: "btn btn-success btn-sm",
                          disabled: $setup.processingId !== null,
                          onClick: $event => ($setup.handleConfirm(slot))
                        }, " Confirm Transfer ", 8 /* PROPS */, _hoisted_30))
                      : _createCommentVNode("v-if", true),
                    ($setup.isAdmin && slot.status === 'Pending Admin Sign-off')
                      ? (_openBlock(), _createElementBlock("button", {
                          key: 4,
                          class: "btn btn-outline-danger btn-sm",
                          disabled: $setup.processingId !== null,
                          onClick: $event => ($setup.handleReject(slot))
                        }, " Reject Transfer ", 8 /* PROPS */, _hoisted_31))
                      : _createCommentVNode("v-if", true)
                  ])
                ])
              ]))
            }), 128 /* KEYED_FRAGMENT */))
          ]))
  ]))
}



_sfc_main.__hmrId = "7a7a37b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"C:/Users/Jeric/Downloads/WAD2 Group Github/IS216-WAD2-Team-13/src/App.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxyXG5pbXBvcnQgeyByZWYsIG9uTW91bnRlZCwgY29tcHV0ZWQgfSBmcm9tICd2dWUnO1xyXG5pbXBvcnQgeyBmYWNpbGl0eVNlcnZpY2UsIGdldFN0YXR1c0JhZGdlQ2xhc3MgfSBmcm9tICcuL3NlcnZpY2VzL2ZhY2lsaXR5U2VydmljZSc7XHJcblxyXG5jb25zdCBzbG90cyA9IHJlZihbXSlcclxuY29uc3QgbG9hZGluZyA9IHJlZih0cnVlKVxyXG5jb25zdCBwcm9jZXNzaW5nSWQgPSByZWYobnVsbClcclxuY29uc3QgdG9hc3QgPSByZWYoJycpXHJcblxyXG4vLyBBRERFRDogc2ltdWxhdGVkIHJvbGUgIChubyByZWFsIGF1dGhlbnRpY2F0aW9uKS5cclxuY29uc3Qgc2VsZWN0ZWRSb2xlID0gcmVmKCdjbHViJylcclxuY29uc3Qgc2VsZWN0ZWRDbHViID0gcmVmKCdFdXJoeXRobWl4JylcclxuY29uc3QgY2x1YnMgPSBbXHJcbiAgJ0FyZGllbnRlJyxcclxuICAnQXJ0ZGljdGVkJyxcclxuICAnQmFsbGFyZScsXHJcbiAgJ0Jyb2FkY2FzdCAmIEVudGVydGFpbm1lbnQnLFxyXG4gICdDYWRlcmFzIExhdGluYXMnLFxyXG4gICdDaGFtYmVyIENob2lyJyxcclxuICAnQ2hpbmVzZSBPcmNoZXN0cmEnLFxyXG4gICdFdXJoeXRobWl4JyxcclxuICAnRnVuayBNb3ZlbWVudCcsXHJcbiAgJ0d1aXRhcmlzc2ltbycsXHJcbiAgJ0lOREFOQ0lUWScsXHJcbiAgJ0l2b3J5IEtleXMnLFxyXG4gICdMaXRlcmF0aScsXHJcbiAgJ01hbGF5IExhbmd1YWdlICYgQ3VsdHVyYWwgQ2x1YicsXHJcbiAgJ1NNVVNBSUMnLFxyXG4gICdTYW1iYSBNYXNhbGEnLFxyXG4gICdTb3VuZEZvdW5kcnknLFxyXG4gICdTdGFnZWl0JyxcclxuICAnU3RlcmVvbWV0YScsXHJcbiAgJ1N5bXBob25pYScsXHJcbiAgJ1ZPSVgnLFxyXG4gICdBQ0YgRXhDbycsXHJcbl1cclxuY29uc3QgaXNBZG1pbiA9IGNvbXB1dGVkKCgpID0+IHNlbGVjdGVkUm9sZS52YWx1ZSA9PT0gJ2FkbWluJylcclxuY29uc3QgcHJvZmlsZU1lbnVPcGVuID0gcmVmKGZhbHNlKVxyXG5jb25zdCB0b2FzdFR5cGUgPSByZWYoJ2luZm8nKVxyXG5cclxuLy8gQURERUQ6IHZlbnVlIGNhdGVnb3J5IGZpbHRlciB0YWJzICh2YWx1ZXMgbWF0Y2ggdmVudWVfdHlwZSBpbiB0aGUgZGF0YSkuXHJcbmNvbnN0IGNhdGVnb3JpZXMgPSBbXHJcbiAgeyBsYWJlbDogJ0FsbCBWZW51ZXMnLCB2YWx1ZTogJ0FsbCcgfSxcclxuICB7IGxhYmVsOiAnRGFuY2UgU3R1ZGlvcycsIHZhbHVlOiAnRGFuY2UgU3R1ZGlvJyB9LFxyXG4gIHsgbGFiZWw6ICdBY291c3RpYyBSb29tcycsIHZhbHVlOiAnQWNvdXN0aWMgUm9vbScgfSxcclxuICB7IGxhYmVsOiAnU3BvcnRzIENvdXJ0cycsIHZhbHVlOiAnU3BvcnRzIENvdXJ0JyB9LFxyXG4gIHsgbGFiZWw6ICdNdWx0aS1QdXJwb3NlJywgdmFsdWU6ICdNdWx0aS1QdXJwb3NlJyB9LFxyXG5dXHJcbmNvbnN0IHNlbGVjdGVkQ2F0ZWdvcnkgPSByZWYoJ0FsbCcpXHJcbmNvbnN0IGZpbHRlcmVkU2xvdHMgPSBjb21wdXRlZCgoKSA9PlxyXG4gIHNlbGVjdGVkQ2F0ZWdvcnkudmFsdWUgPT09ICdBbGwnXHJcbiAgICA/IHNsb3RzLnZhbHVlXHJcbiAgICA6IHNsb3RzLnZhbHVlLmZpbHRlcigoc2xvdCkgPT4gc2xvdC52ZW51ZV90eXBlID09PSBzZWxlY3RlZENhdGVnb3J5LnZhbHVlKVxyXG4pXHJcblxyXG5mdW5jdGlvbiBzZWxlY3RQcm9maWxlKHJvbGUpIHtcclxuICBzZWxlY3RlZFJvbGUudmFsdWUgPSByb2xlXHJcbiAgcHJvZmlsZU1lbnVPcGVuLnZhbHVlID0gZmFsc2VcclxuICB0b2FzdC52YWx1ZSA9ICcnXHJcbn1cclxuYXN5bmMgZnVuY3Rpb24gbG9hZFNsb3RzKCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZhY2lsaXR5U2VydmljZS5nZXRTbG90cygpXHJcbiAgc2xvdHMudmFsdWUgPSByZXMuZGF0YSB8fCBbXVxyXG59XHJcblxyXG4vL2hhbmRsZXMgZGlmZmVyZW50IGZhY2lsaXR5IGFjdGlvbnNcclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWN0aW9uKHNsb3QsIGFjdGlvbiwgbWVzc2FnZSkge1xyXG4gIGlmIChwcm9jZXNzaW5nSWQudmFsdWUgIT09IG51bGwpIHJldHVyblxyXG4gIHByb2Nlc3NpbmdJZC52YWx1ZSA9IHNsb3QuaWRcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYWN0aW9uKClcclxuICAgIGlmICghcmVzdWx0LnN1Y2Nlc3MgfHwgIXJlc3VsdC5kYXRhKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byB1cGRhdGUgZmFjaWxpdHknKVxyXG4gICAgYXdhaXQgbG9hZFNsb3RzKClcclxuICAgIHRvYXN0VHlwZS52YWx1ZSA9ICdzdWNjZXNzJ1xyXG4gICAgdG9hc3QudmFsdWUgPSBtZXNzYWdlXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHRvYXN0VHlwZS52YWx1ZSA9ICdkYW5nZXInXHJcbiAgICB0b2FzdC52YWx1ZSA9IGBFcnJvcjogJHtlcnJvci5tZXNzYWdlfWBcclxuICB9IGZpbmFsbHkge1xyXG4gICAgcHJvY2Vzc2luZ0lkLnZhbHVlID0gbnVsbFxyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlUmVsZWFzZShzbG90KSB7XHJcbiAgYXdhaXQgaGFuZGxlQWN0aW9uKHNsb3QsXHJcbiAgICAoKSA9PiBmYWNpbGl0eVNlcnZpY2UucmVsZWFzZVNsb3Qoc2xvdC5pZCwgc2VsZWN0ZWRDbHViLnZhbHVlKSxcclxuICAgIGAke3Nsb3QudmVudWVfbmFtZX0gcmVsZWFzZWQgdG8gbWFya2V0cGxhY2UhYClcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlQ29uZmlybShzbG90KSB7XHJcbiAgYXdhaXQgaGFuZGxlQWN0aW9uKHNsb3QsXHJcbiAgICAoKSA9PiBmYWNpbGl0eVNlcnZpY2UuY29uZmlybVBlZXJUcmFuc2ZlcihzbG90LmlkKSxcclxuICAgIGAke3Nsb3QudmVudWVfbmFtZX0gdHJhbnNmZXIgY29uZmlybWVkIWApXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZUNsYWltKHNsb3QpIHtcclxuICBhd2FpdCBoYW5kbGVBY3Rpb24oc2xvdCxcclxuICAgICgpID0+IGZhY2lsaXR5U2VydmljZS5jbGFpbVNsb3Qoc2xvdC5pZCwgc2VsZWN0ZWRDbHViLnZhbHVlKSxcclxuICAgIGAke3Nsb3QudmVudWVfbmFtZX0gY2xhaW0gc3VibWl0dGVkIGZvciBhZG1pbiBhcHByb3ZhbCFgKVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVVbmRvKHNsb3QpIHtcclxuICBhd2FpdCBoYW5kbGVBY3Rpb24oc2xvdCxcclxuICAgICgpID0+IGZhY2lsaXR5U2VydmljZS51bmRvUmVsZWFzZShzbG90LmlkLCBzZWxlY3RlZENsdWIudmFsdWUpLFxyXG4gICAgYCR7c2xvdC52ZW51ZV9uYW1lfSByZWxlYXNlIHVuZG9uZSFgKVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVSZWplY3Qoc2xvdCkge1xyXG4gIGF3YWl0IGhhbmRsZUFjdGlvbihzbG90LFxyXG4gICAgKCkgPT4gZmFjaWxpdHlTZXJ2aWNlLnJlamVjdFBlZXJUcmFuc2ZlcihzbG90LmlkKSxcclxuICAgIGAke3Nsb3QudmVudWVfbmFtZX0gY2xhaW0gcmVqZWN0ZWQ7IHNsb3QgYXZhaWxhYmxlIGZvciBjbGFpbSBhZ2FpbiFgKVxyXG59XHJcblxyXG5vbk1vdW50ZWQoYXN5bmMgKCkgPT4ge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBsb2FkU2xvdHMoKVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICB0b2FzdFR5cGUudmFsdWUgPSAnZGFuZ2VyJ1xyXG4gICAgdG9hc3QudmFsdWUgPSBgRXJyb3IgbG9hZGluZyBmYWNpbGl0aWVzOiAke2Vycm9yLm1lc3NhZ2V9YFxyXG4gIH0gZmluYWxseSB7XHJcbiAgICBsb2FkaW5nLnZhbHVlID0gZmFsc2VcclxuICB9XHJcbn0pXHJcbjwvc2NyaXB0PlxyXG5cclxuPHRlbXBsYXRlPlxyXG4gIDxkaXYgY2xhc3M9XCJjb250YWluZXIgcHktNFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBhbGlnbi1pdGVtcy1jZW50ZXIgbWItNCBnYXAtM1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwidGV4dC1zdGFydFwiPlxyXG4gICAgICAgIDxoMiBjbGFzcz1cImZ3LWJvbGQgbWItMFwiPlB1bHNlIC0gTWFzdGVyIEZhY2lsaXR5IENhbGVuZGFyPC9oMj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiYmFkZ2UgYmctZGFuZ2VyIG10LTMgdy01MCBcIj5cclxuICAgICAgICAgIHt7IGlzQWRtaW4gPyAnRmFjaWxpdHkgQWRtaW4nIDogc2VsZWN0ZWRDbHViICsgJyBFWENPJyB9fVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPC9kaXY+XHJcblxyXG48IS0tIFJlc2V0IGJ1dHRvbiBmb3IgZGVtbyBwYWdlIC0tPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3M9XCJidG4gYnRuLW91dGxpbmUtZGFuZ2VyIGJ0bi1zbVwiXHJcblxyXG4gICAgICAgICAgQGNsaWNrPVwiZmFjaWxpdHlTZXJ2aWNlLnJlc2V0RGF0YSgpLnRoZW4oKCkgPT4geyBsb2FkU2xvdHMoKTsgdG9hc3QgPSAnJzsgfSlcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIFJlc2V0IERlbW9cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIDwhLS0gUHJvZmlsZSBtZW51OiBzd2l0Y2ggYmV0d2VlbiBDbHViIEVYQ08gYW5kIEZhY2lsaXR5IEFkbWluIC0tPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwicG9zaXRpb24tcmVsYXRpdmVcIj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXNlY29uZGFyeSBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgIDphcmlhLWV4cGFuZGVkPVwicHJvZmlsZU1lbnVPcGVuXCJcclxuICAgICAgICAgIEBjbGljaz1cInByb2ZpbGVNZW51T3BlbiA9ICFwcm9maWxlTWVudU9wZW5cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPvCfkaQ8L3NwYW4+XHJcbiAgICAgICAgICB7eyBpc0FkbWluID8gJ0ZhY2lsaXR5IEFkbWluJyA6ICdDbHViIEVYQ08nIH19XHJcbiAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7ilr48L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGRpdiB2LWlmPVwicHJvZmlsZU1lbnVPcGVuXCIgY2xhc3M9XCJjYXJkIHNoYWRvdyBwb3NpdGlvbi1hYnNvbHV0ZSBlbmQtMCBtdC0yIHAtMlwiIHN0eWxlPVwibWluLXdpZHRoOiAxOTBweDsgei1pbmRleDogMTA7XCI+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tbGlnaHQgdGV4dC1zdGFydCBtYi0xXCIgQGNsaWNrPVwic2VsZWN0UHJvZmlsZSgnY2x1YicpXCI+XHJcbiAgICAgICAgICAgIENsdWIgRVhDT1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0biBidG4tbGlnaHQgdGV4dC1zdGFydFwiIEBjbGljaz1cInNlbGVjdFByb2ZpbGUoJ2FkbWluJylcIj5cclxuICAgICAgICAgICAgRmFjaWxpdHkgQWRtaW5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG4gICAgPCEtLSBDbHViIHN3aXRjaGVyIGFwcGVhcnMgb25seSBmb3IgQ2x1YiBFWENPIC0tPlxyXG4gICAgPGRpdiB2LWlmPVwiIWlzQWRtaW5cIiBjbGFzcz1cIm1iLTNcIj5cclxuICAgICAgPGxhYmVsIGZvcj1cImNsdWJTd2l0Y2hlclwiIGNsYXNzPVwiZm9ybS1sYWJlbCBmdy1ib2xkXCI+Q2x1YiBTd2l0Y2hlcjwvbGFiZWw+XHJcbiAgICAgIDxzZWxlY3QgaWQ9XCJjbHViU3dpdGNoZXJcIiB2LW1vZGVsPVwic2VsZWN0ZWRDbHViXCIgY2xhc3M9XCJmb3JtLXNlbGVjdFwiIEBjaGFuZ2U9XCJ0b2FzdCA9ICcnXCI+XHJcbiAgICAgICAgPG9wdGlvbiB2LWZvcj1cImNsdWIgaW4gY2x1YnNcIiA6a2V5PVwiY2x1YlwiIDp2YWx1ZT1cImNsdWJcIj57eyBjbHViIH19PC9vcHRpb24+XHJcbiAgICAgIDwvc2VsZWN0PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cImFsZXJ0IGFsZXJ0LWxpZ2h0IGJvcmRlciBtYi0zXCI+XHJcbiAgICAgIDxzdHJvbmc+RmFjaWxpdHkgQWRtaW4gPC9zdHJvbmc+IFxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBWZW51ZSBjYXRlZ29yeSBmaWx0ZXIgdGFicyAtLT5cclxuICAgIDx1bCBjbGFzcz1cIm5hdiBuYXYtcGlsbHMgbWItM1wiPlxyXG4gICAgICA8bGkgdi1mb3I9XCJjYXRlZ29yeSBpbiBjYXRlZ29yaWVzXCIgOmtleT1cImNhdGVnb3J5LnZhbHVlXCIgY2xhc3M9XCJuYXYtaXRlbVwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3M9XCJuYXYtbGlua1wiXHJcbiAgICAgICAgICA6Y2xhc3M9XCJ7IGFjdGl2ZTogc2VsZWN0ZWRDYXRlZ29yeSA9PT0gY2F0ZWdvcnkudmFsdWUgfVwiXHJcbiAgICAgICAgICBAY2xpY2s9XCJzZWxlY3RlZENhdGVnb3J5ID0gY2F0ZWdvcnkudmFsdWVcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt7IGNhdGVnb3J5LmxhYmVsIH19XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvbGk+XHJcbiAgICA8L3VsPlxyXG5cclxuICAgIDwhLS0gT3JpZ2luYWwgYWxlcnQgYmFubmVyOiBzaG93biBvbmx5IGZvciB0aGUgdXNlciBjbGlja2luZyBhbiBhY3Rpb24gLS0+XHJcbiAgICA8ZGl2IHYtaWY9XCJ0b2FzdFwiIGNsYXNzPVwiYWxlcnQgYWxlcnQtZGlzbWlzc2libGUgZmFkZSBzaG93XCIgOmNsYXNzPVwiYGFsZXJ0LSR7dG9hc3RUeXBlfWBcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAge3sgdG9hc3QgfX1cclxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2xvc2VcIiBAY2xpY2s9XCJ0b2FzdCA9ICcnXCI+PC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IHYtaWY9XCJsb2FkaW5nXCIgY2xhc3M9XCJ0ZXh0LWNlbnRlciBweS01XCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyLWJvcmRlciB0ZXh0LWRhbmdlclwiIHJvbGU9XCJzdGF0dXNcIj48L2Rpdj5cclxuICAgICAgPHAgY2xhc3M9XCJ0ZXh0LW11dGVkIG10LTJcIj5Mb2FkaW5nIGZhY2lsaXR5IHNsb3RzLi4uPC9wPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPHAgdi1lbHNlLWlmPVwiIWZpbHRlcmVkU2xvdHMubGVuZ3RoXCIgY2xhc3M9XCJ0ZXh0LWNlbnRlciB0ZXh0LW11dGVkIHB5LTVcIj5cclxuICAgICAgTm8gZmFjaWxpdHkgc2xvdHMgaW4gdGhpcyBjYXRlZ29yeS5cclxuICAgIDwvcD5cclxuXHJcbiAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cInJvd1wiPlxyXG4gICAgICA8ZGl2IHYtZm9yPVwic2xvdCBpbiBmaWx0ZXJlZFNsb3RzXCIgOmtleT1cInNsb3QuaWRcIiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBwLTMgc2hhZG93LXNtIGgtMTAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIGFsaWduLWl0ZW1zLXN0YXJ0XCI+XHJcbiAgICAgICAgICAgIDxoNSBjbGFzcz1cImZ3LWJvbGQgbWItMVwiPnt7IHNsb3QudmVudWVfbmFtZSB9fTwvaDU+XHJcbiAgICAgICAgICAgIDxzcGFuIDpjbGFzcz1cImdldFN0YXR1c0JhZGdlQ2xhc3Moc2xvdC5zdGF0dXMpXCI+e3sgc2xvdC5zdGF0dXMgfX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxzbWFsbCBjbGFzcz1cInRleHQtbXV0ZWQgbWItMlwiPnt7IHNsb3QuYnVpbGRpbmdfbG9jYXRpb24gfX08L3NtYWxsPlxyXG4gICAgICAgICAgPHAgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5UaW1lOjwvc3Ryb25nPiB7eyBzbG90LnRpbWVfc2xvdCB9fTwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzPVwibWItMCB0ZXh0LW11dGVkIHNtYWxsXCI+PHN0cm9uZz5Pd25lcjo8L3N0cm9uZz4ge3sgc2xvdC5vd25lcl9jbHViIH19PC9wPlxyXG4gICAgICAgICAgPHAgdi1pZj1cInNsb3QuY2xhaW1pbmdfY2x1YlwiIGNsYXNzPVwibWItMCB0ZXh0LW11dGVkIHNtYWxsXCI+PHN0cm9uZz5DbGFpbWluZyBDbHViOjwvc3Ryb25nPiB7eyBzbG90LmNsYWltaW5nX2NsdWIgfX08L3A+XHJcbiAgICAgICAgICA8cCB2LWlmPVwic2xvdC5hdWRpdF90aWNrZXRfaWRcIiBjbGFzcz1cIm1iLTAgdGV4dC1tdXRlZCBzbWFsbFwiPjxzdHJvbmc+QXVkaXQgVGlja2V0Ojwvc3Ryb25nPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBiZy1kYXJrIGZvbnQtbW9ub3NwYWNlIG1zLTFcIj57eyBzbG90LmF1ZGl0X3RpY2tldF9pZCB9fTwvc3Bhbj48L3A+XHJcblxyXG5cclxuICAgICAgICAgIDwhLS0gU2FtZSBhY3Rpb24gYnV0dG9uIHNlY3Rpb24sIHdpdGggcm9sZS1zcGVjaWZpYyBjb25kaXRpb25zIC0tPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm10LWF1dG8gZC1mbGV4IGZsZXgtd3JhcCBnYXAtMiBwdC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB2LWlmPVwiIWlzQWRtaW4gJiYgKHNsb3Quc3RhdHVzID09PSAnQm9va2VkJyB8fCBzbG90LnN0YXR1cyA9PT0gJ09mZmljaWFsbHkgQ29uZmlybWVkJykgJiYgc2xvdC5vd25lcl9jbHViID09PSBzZWxlY3RlZENsdWJcIlxyXG4gICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1vdXRsaW5lLXByaW1hcnkgYnRuLXNtXCJcclxuICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJwcm9jZXNzaW5nSWQgIT09IG51bGxcIlxyXG4gICAgICAgICAgICAgIEBjbGljaz1cImhhbmRsZVJlbGVhc2Uoc2xvdClcIj5cclxuICAgICAgICAgICAgICBSZWxlYXNlIHRvIE1hcmtldHBsYWNlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHYtaWY9XCIhaXNBZG1pbiAmJiBzbG90LnN0YXR1cyA9PT0gJ1Byb3Bvc2VkIFBlZXIgVHJhbnNmZXInICYmIHNsb3Qub3duZXJfY2x1YiA9PT0gc2VsZWN0ZWRDbHViXCJcclxuICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1zZWNvbmRhcnkgYnRuLXNtXCJcclxuICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJwcm9jZXNzaW5nSWQgIT09IG51bGxcIlxyXG4gICAgICAgICAgICAgIEBjbGljaz1cImhhbmRsZVVuZG8oc2xvdClcIj5cclxuICAgICAgICAgICAgICBVbmRvIFJlbGVhc2VcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdi1pZj1cIiFpc0FkbWluICYmIHNsb3Quc3RhdHVzID09PSAnUHJvcG9zZWQgUGVlciBUcmFuc2ZlcicgJiYgc2xvdC5vd25lcl9jbHViICE9PSBzZWxlY3RlZENsdWJcIlxyXG4gICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiXHJcbiAgICAgICAgICAgICAgOmRpc2FibGVkPVwicHJvY2Vzc2luZ0lkICE9PSBudWxsXCJcclxuICAgICAgICAgICAgICBAY2xpY2s9XCJoYW5kbGVDbGFpbShzbG90KVwiPlxyXG4gICAgICAgICAgICAgIENsYWltIEZhY2lsaXR5XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHYtaWY9XCJpc0FkbWluICYmIHNsb3Quc3RhdHVzID09PSAnUGVuZGluZyBBZG1pbiBTaWduLW9mZidcIlxyXG4gICAgICAgICAgICAgIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbVwiXHJcbiAgICAgICAgICAgICAgOmRpc2FibGVkPVwicHJvY2Vzc2luZ0lkICE9PSBudWxsXCJcclxuICAgICAgICAgICAgICBAY2xpY2s9XCJoYW5kbGVDb25maXJtKHNsb3QpXCI+XHJcbiAgICAgICAgICAgICAgQ29uZmlybSBUcmFuc2ZlclxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB2LWlmPVwiaXNBZG1pbiAmJiBzbG90LnN0YXR1cyA9PT0gJ1BlbmRpbmcgQWRtaW4gU2lnbi1vZmYnXCJcclxuICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tb3V0bGluZS1kYW5nZXIgYnRuLXNtXCJcclxuICAgICAgICAgICAgICA6ZGlzYWJsZWQ9XCJwcm9jZXNzaW5nSWQgIT09IG51bGxcIlxyXG4gICAgICAgICAgICAgIEBjbGljaz1cImhhbmRsZVJlamVjdChzbG90KVwiPlxyXG4gICAgICAgICAgICAgIFJlamVjdCBUcmFuc2ZlclxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG48L3RlbXBsYXRlPlxyXG4iXSwibWFwcGluZ3MiOiJBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xGOzs7Ozs7QUFIYztBQUlkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckI7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdELENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekUsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQzs7Ozs7Ozs7OztxQkFJSyxLQUFLLEVBQUMsZ0JBQWdCO3FCQUNwQixLQUFLLEVBQUMsOERBQThEO3FCQUNsRSxLQUFLLEVBQUMsWUFBWTtxQkFFaEIsS0FBSyxFQUFDLDJCQUE0QjtxQkFPcEMsS0FBSyxFQUFDLGlDQUFpQztxQkFXdkMsS0FBSyxFQUFDLG1CQUFtQjs7OztFQVdBLEtBQUssRUFBQyw4Q0FBOEM7RUFBQyxLQUFzQyxFQUF0QyxvQ0FBc0M7Ozs7RUFZdEcsS0FBSyxFQUFDLE1BQU07Ozs7O0VBTXJCLEtBQUssRUFBQywrQkFBK0I7O3NCQUs3QyxLQUFLLEVBQUMsb0JBQW9COzs7O0VBbUJWLEtBQUssRUFBQyxrQkFBa0I7Ozs7RUFLUCxLQUFLLEVBQUMsNkJBQTZCOzs7O0VBSTVELEtBQUssRUFBQyxLQUFLOztzQkFFZCxLQUFLLEVBQUMsMEJBQTBCO3NCQUM5QixLQUFLLEVBQUMsa0RBQWtEO3NCQUN2RCxLQUFLLEVBQUMsY0FBYztzQkFHbkIsS0FBSyxFQUFDLGlCQUFpQjtzQkFDM0IsS0FBSyxFQUFDLE1BQU07c0JBQ1osS0FBSyxFQUFDLHVCQUF1Qjs7O0VBQ0gsS0FBSyxFQUFDLHVCQUF1Qjs7OztFQUMzQixLQUFLLEVBQUMsdUJBQXVCOztzQkFDdEQsS0FBSyxFQUFDLG1DQUFtQztzQkFJMUMsS0FBSyxFQUFDLHFDQUFxQzs7Ozs7Ozs7d0JBcEd4RCxvQkFnSk0sT0FoSk4sVUFnSk07SUEvSUosb0JBMENJLE9BMUNKLFVBMENJO01BekNGLG9CQU1NLE9BTk4sVUFNTTtrQ0FMSixvQkFBOEQsUUFBMUQsS0FBSyxFQUFDLGNBQWMsSUFBQyxrQ0FBZ0M7UUFDekQsb0JBRU0sT0FGTixVQUVNLG1CQURELGNBQU8sc0JBQXNCLG1CQUFZOztNQUt0RCxtREFBbUM7TUFDN0Isb0JBK0JJLE9BL0JKLFVBK0JJO1FBOUJGLG9CQU9TO1VBTlAsSUFBSSxFQUFDLFFBQVE7VUFDYixLQUFLLEVBQUMsK0JBQStCO1VBRXBDLE9BQUssdUNBQUUsc0JBQWUsQ0FBQyxTQUFTLEdBQUcsSUFBSSxTQUFTLGdCQUFTLElBQUksWUFBSztXQUNwRSxjQUVEO1FBRUYsa0ZBQWtFO1FBQ2xFLG9CQW1CTSxPQW5CTixVQW1CTTtVQWxCSixvQkFTUztZQVJQLElBQUksRUFBQyxRQUFRO1lBQ2IsS0FBSyxFQUFDLDJEQUEyRDtZQUNoRSxlQUFhLEVBQUUsc0JBQWU7WUFDOUIsT0FBSyx1Q0FBRSxzQkFBZSxJQUFJLHNCQUFlOztzQ0FFMUMsb0JBQWtDLFVBQTVCLGFBQVcsRUFBQyxNQUFNLElBQUMsSUFBRTs2QkFBTyxHQUNsQyxvQkFBRyxjQUFPLHFDQUFvQyxHQUM5QztzQ0FBQSxvQkFBaUMsVUFBM0IsYUFBVyxFQUFDLE1BQU0sSUFBQyxHQUFDOztXQUVqQixzQkFBZTs2QkFBMUIsb0JBT00sT0FQTixVQU9NO2dCQU5KLG9CQUVTO2tCQUZELElBQUksRUFBQyxRQUFRO2tCQUFDLEtBQUssRUFBQywrQkFBK0I7a0JBQUUsT0FBSyx1Q0FBRSxvQkFBYTttQkFBVSxhQUUzRjtnQkFDQSxvQkFFUztrQkFGRCxJQUFJLEVBQUMsUUFBUTtrQkFBQyxLQUFLLEVBQUMsMEJBQTBCO2tCQUFFLE9BQUssdUNBQUUsb0JBQWE7bUJBQVcsa0JBRXZGOzs7Ozs7SUFLTixpRUFBaUQ7TUFDckMsY0FBTzt1QkFBbkIsb0JBS00sT0FMTixVQUtNO3NDQUpKLG9CQUEwRTtZQUFuRSxHQUFHLEVBQUMsY0FBYztZQUFDLEtBQUssRUFBQyxvQkFBb0I7YUFBQyxlQUFhOzBCQUNsRSxvQkFFUztZQUZELEVBQUUsRUFBQyxjQUFjO3lFQUFVLG1CQUFZO1lBQUUsS0FBSyxFQUFDLGFBQWE7WUFBRSxRQUFNLHVDQUFFLFlBQUs7OzJCQUNqRixvQkFBMkUsNkJBQXBELFlBQUssR0FBYixJQUFJO3FCQUFuQixvQkFBMkU7Z0JBQTVDLEdBQUcsRUFBRSxJQUFJO2dCQUFHLEtBQUssRUFBRSxJQUFJO2tDQUFLLElBQUk7Ozs0QkFEOUIsbUJBQVk7Ozt1QkFJakQsb0JBRU0sT0FGTixXQUVNO1VBREosb0JBQWdDLGdCQUF4QixpQkFBZTs7SUFHekIsbURBQW1DO0lBQ25DLG9CQVdLLE1BWEwsV0FXSztxQkFWSCxvQkFTSyw2QkFUa0IsaUJBQVUsR0FBdEIsUUFBUTtlQUFuQixvQkFTSztVQVQrQixHQUFHLEVBQUUsUUFBUSxDQUFDLEtBQUs7VUFBRSxLQUFLLEVBQUMsVUFBVTs7VUFDdkUsb0JBT1M7WUFOUCxJQUFJLEVBQUMsUUFBUTtZQUNiLEtBQUssbUJBQUMsVUFBVSxZQUNFLHVCQUFnQixLQUFLLFFBQVEsQ0FBQyxLQUFLO1lBQ3BELE9BQUssYUFBRSx1QkFBZ0IsR0FBRyxRQUFRLENBQUMsS0FBSzs4QkFFdEMsUUFBUSxDQUFDLEtBQUs7Ozs7SUFLdkIsMEZBQTBFO0tBQy9ELFlBQUs7dUJBQWhCLG9CQUdNOztVQUhZLEtBQUssbUJBQUMsbUNBQW1DLFdBQWtCLGdCQUFTO1VBQUksSUFBSSxFQUFDLE9BQU87OzRDQUNqRyxZQUFLLElBQUcsR0FDWDtVQUFBLG9CQUFxRTtZQUE3RCxJQUFJLEVBQUMsUUFBUTtZQUFDLEtBQUssRUFBQyxXQUFXO1lBQUUsT0FBSyx1Q0FBRSxZQUFLOzs7O0tBRzVDLGNBQU87dUJBQWxCLG9CQUdNLE9BSE4sV0FHTTtVQUZKLG9CQUE0RDtZQUF2RCxLQUFLLEVBQUMsNEJBQTRCO1lBQUMsSUFBSSxFQUFDLFFBQVE7O1VBQ3JELG9CQUF3RCxPQUFyRCxLQUFLLEVBQUMsaUJBQWlCLElBQUMsMkJBQXlCOztVQUd2QyxvQkFBYSxDQUFDLE1BQU07eUJBQW5DLG9CQUVJLEtBRkosV0FFSSxFQUZxRSx1Q0FFekU7eUJBRUEsb0JBMkRNLE9BM0ROLFdBMkRNOytCQTFESixvQkF5RE0sNkJBekRjLG9CQUFhLEdBQXJCLElBQUk7b0NBQWhCLG9CQXlETTtnQkF6RDhCLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFBRTtnQkFBRSxLQUFLLEVBQUMsZUFBZTs7Z0JBQ3JFLG9CQXVETSxPQXZETixXQXVETTtrQkF0REosb0JBR00sT0FITixXQUdNO29CQUZKLG9CQUFtRCxNQUFuRCxXQUFtRCxtQkFBdkIsSUFBSSxDQUFDLFVBQVU7b0JBQzNDLG9CQUF3RTtzQkFBakUsS0FBSyxrQkFBRSwwQkFBbUIsQ0FBQyxJQUFJLENBQUMsTUFBTTt3Q0FBTSxJQUFJLENBQUMsTUFBTTs7a0JBRWhFLG9CQUFtRSxTQUFuRSxXQUFtRSxtQkFBakMsSUFBSSxDQUFDLGlCQUFpQjtrQkFDeEQsb0JBQStELEtBQS9ELFdBQStEO2dEQUEvQyxvQkFBc0IsZ0JBQWQsT0FBSztxQ0FBUyxHQUFDLG9CQUFHLElBQUksQ0FBQyxTQUFTOztrQkFDeEQsb0JBQWtGLEtBQWxGLFdBQWtGO2dEQUFqRCxvQkFBdUIsZ0JBQWYsUUFBTTtxQ0FBUyxHQUFDLG9CQUFHLElBQUksQ0FBQyxVQUFVOzttQkFDbEUsSUFBSSxDQUFDLGFBQWE7cUNBQTNCLG9CQUF1SCxLQUF2SCxXQUF1SDtvREFBNUQsb0JBQStCLGdCQUF2QixnQkFBYzt5Q0FBUyxHQUFDLG9CQUFHLElBQUksQ0FBQyxhQUFhOzs7bUJBQ3ZHLElBQUksQ0FBQyxlQUFlO3FDQUE3QixvQkFDcUYsS0FEckYsV0FDcUY7b0RBRHhCLG9CQUE4QixnQkFBdEIsZUFBYTt3QkFDbEYsb0JBQWlGLFFBQWpGLFdBQWlGLG1CQUE5QixJQUFJLENBQUMsZUFBZTs7O2tCQUd2RSxrRkFBa0U7a0JBQ2xFLG9CQXdDTSxPQXhDTixXQXdDTTtzQkF0Q0ssY0FBTyxLQUFLLElBQUksQ0FBQyxNQUFNLGlCQUFpQixJQUFJLENBQUMsTUFBTSxnQ0FBZ0MsSUFBSSxDQUFDLFVBQVUsS0FBSyxtQkFBWTt1Q0FENUgsb0JBTVM7OzBCQUpQLEtBQUssRUFBQyxnQ0FBZ0M7MEJBQ3JDLFFBQVEsRUFBRSxtQkFBWTswQkFDdEIsT0FBSyxhQUFFLG9CQUFhLENBQUMsSUFBSTsyQkFBRywwQkFFL0I7O3NCQUdTLGNBQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxpQ0FBaUMsSUFBSSxDQUFDLFVBQVUsS0FBSyxtQkFBWTt1Q0FEaEcsb0JBTVM7OzBCQUpQLEtBQUssRUFBQyxrQ0FBa0M7MEJBQ3ZDLFFBQVEsRUFBRSxtQkFBWTswQkFDdEIsT0FBSyxhQUFFLGlCQUFVLENBQUMsSUFBSTsyQkFBRyxnQkFFNUI7O3NCQUdTLGNBQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxpQ0FBaUMsSUFBSSxDQUFDLFVBQVUsS0FBSyxtQkFBWTt1Q0FEaEcsb0JBTVM7OzBCQUpQLEtBQUssRUFBQyx3QkFBd0I7MEJBQzdCLFFBQVEsRUFBRSxtQkFBWTswQkFDdEIsT0FBSyxhQUFFLGtCQUFXLENBQUMsSUFBSTsyQkFBRyxrQkFFN0I7O3FCQUdRLGNBQU8sSUFBSSxJQUFJLENBQUMsTUFBTTt1Q0FEOUIsb0JBTVM7OzBCQUpQLEtBQUssRUFBQyx3QkFBd0I7MEJBQzdCLFFBQVEsRUFBRSxtQkFBWTswQkFDdEIsT0FBSyxhQUFFLG9CQUFhLENBQUMsSUFBSTsyQkFBRyxvQkFFL0I7O3FCQUdRLGNBQU8sSUFBSSxJQUFJLENBQUMsTUFBTTt1Q0FEOUIsb0JBTVM7OzBCQUpQLEtBQUssRUFBQywrQkFBK0I7MEJBQ3BDLFFBQVEsRUFBRSxtQkFBWTswQkFDdEIsT0FBSyxhQUFFLG1CQUFZLENBQUMsSUFBSTsyQkFBRyxtQkFFOUIiLCJpZ25vcmVMaXN0IjpbXX0=